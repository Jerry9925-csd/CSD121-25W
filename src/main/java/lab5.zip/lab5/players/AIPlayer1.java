package lab5.players;

/*
omola
 */

import lab5.game.Board;
import lab5.game.Position;
import lab5.game.PlayerToken;
import java.util.List;

public class AIPlayer1 extends Player {
    public AIPlayer1() {
        super("AiPlayer1");
    }

    @Override
    public Position pickNextMove(Board board) {
        List<Position> emptyCells = board.getEmptyCells();
        PlayerToken myToken = board.getNextTurnToken();

        // Check for a winning move
        for (Position pos : emptyCells) {
            Board copy = new Board(board);
            copy.placeNextToken(pos);
            if (copy.getWinner()) return pos;
        }

        // Block opponent’s winning move
        for (Position pos : emptyCells) {
            Board copy = new Board(board);
            copy.placeNextToken(pos);
            if (copy.getWinner()) return pos;
        }

        // Default: Pick the first available move
        return emptyCells.get(0);
    }
}
